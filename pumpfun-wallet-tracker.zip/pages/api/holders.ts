export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const { mints } = req.body;
  if (!Array.isArray(mints) || mints.length === 0) {
    return res.status(400).json({ message: 'Invalid input' });
  }

  const HELIUS_URL = `https://mainnet.helius-rpc.com/?api-key=6a9ff150-d14d-4da8-a861-ba7edfc26bdf`;

  async function fetchHolders(mint) {
    const holders = new Set();
    let page = 1;
    while (true) {
      const response = await fetch(HELIUS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 'getTokenAccounts',
          method: 'getTokenAccounts',
          params: { mint, page, limit: 1000 },
        }),
      });

      const data = await response.json();
      const accounts = data.result?.token_accounts || [];
      for (const acc of accounts) {
        holders.add(acc.owner);
      }
      if (accounts.length < 1000) break;
      page++;
    }
    return holders;
  }

  try {
    let common = await fetchHolders(mints[0]);
    for (let i = 1; i < mints.length; i++) {
      const next = await fetchHolders(mints[i]);
      common = new Set([...common].filter((x) => next.has(x)));
      if (common.size === 0) break;
    }
    return res.status(200).json({ wallets: Array.from(common) });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Internal server error' });
  }
}
