import { useState } from 'react';

export default function Home() {
  const [tokenInputs, setTokenInputs] = useState(['', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [wallets, setWallets] = useState<string[]>([]);
  const [error, setError] = useState('');

  const handleChange = (index: number, value: string) => {
    const newInputs = [...tokenInputs];
    newInputs[index] = value.trim();
    setTokenInputs(newInputs);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError('');
    setWallets([]);

    const mints = tokenInputs.filter((m) => m.length > 0);
    if (mints.length === 0) {
      setError('Please input at least one token mint address.');
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/holders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mints }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Unknown error');

      setWallets(data.wallets);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen p-6 bg-gray-100">
      <div className="max-w-xl mx-auto bg-white p-6 rounded-xl shadow-xl">
        <h1 className="text-2xl font-bold mb-4">Pump.fun Wallet Tracker</h1>
        <p className="text-sm text-gray-600 mb-4">Enter up to 5 Pump.fun token mint addresses to find wallets that bought all of them.</p>

        {tokenInputs.map((input, i) => (
          <input
            key={i}
            className="w-full mb-2 px-4 py-2 border rounded-md"
            placeholder={`Token Mint Address ${i + 1}`}
            value={input}
            onChange={(e) => handleChange(i, e.target.value)}
          />
        ))}

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white font-semibold py-2 mt-2 rounded hover:bg-blue-700"
          disabled={loading}
        >
          {loading ? 'Searching...' : 'Find Common Wallets'}
        </button>

        {error && <p className="text-red-600 mt-4 text-sm">{error}</p>}

        {wallets.length > 0 && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-2">Matching Wallets ({wallets.length})</h2>
            <ul className="text-sm space-y-1">
              {wallets.map((w) => (
                <li
                  key={w}
                  className="break-all bg-gray-100 p-2 rounded hover:bg-gray-200 cursor-pointer"
                  onClick={() => navigator.clipboard.writeText(w)}
                  title="Click to copy"
                >
                  {w}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </main>
  );
}
